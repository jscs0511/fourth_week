#include "array.h"

#ifndef __Growable__
#define __Growable__
template <typename T>
class GrowableArray: public Array <T>
{
	protected:
		int len;
		T *temp;
	public:
		GrowableArray(int a);
		~GrowableArray();
		T &operator[](int);
		T operator[](int ) const;
};
#endif
