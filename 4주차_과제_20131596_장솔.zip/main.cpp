#include "array.h"
#include "growablearray.h"
template <typename T>
Array<T>::Array(int size) {
	data = new T[size];
	len = size;
}
template <typename T>
Array<T>::~Array() {
	delete []data;
}
template <typename T>
int Array<T>::length() {
	return len;
}
template <typename T>
T &Array<T>::operator[] (int i) {
	static T tmp;
	if ( (i >= 0) && ( i < len) )
		return data[i];
	else {
		cout << " Array boud error!\n";
		return tmp;
	}
}
template <typename T>
T Array<T>::operator[] (int i) const {
	if ( ( i>= 0 ) && ( i < len ) )
		return data[i];
	else return 0;
}
template <typename T>
void Array<T>::print() {
	int i ;
	cout << "[";
	for ( i = 0 ; i < len-1 ; i++ ) 
		cout << data[i] << " ";
	cout << data[i] << "]" << endl;
}


template <typename T>
GrowableArray<T>::GrowableArray(int a):Array<T>(a) {
	len = a;
}
template <typename T>
GrowableArray<T>::~GrowableArray() {
	;
}
template <typename T>
T &GrowableArray<T>::operator[](int index) {
	int i;
	if ( index > len ) {
		temp = new T[len];
		for ( i = 0 ; i < len ; i++ ) 
			temp[i] = this->data[i];
	
		Array<T>::data = new T[2*index];
		Array<T>::len = 2*index;
		for ( i = 0 ; i < len ; i++ ) 
			this->data[i] = temp[i];
		for ( i = len ; i < 2*index ; i++ ) 
			this->data[i] = 0;
		delete[] temp;
	}
	return Array<T>::operator[](index);
}
template <typename T>
T GrowableArray<T> ::operator[] (int index) const {
	return Array<T>::operator [](index);
}

int main(void)
{
	cout<<"GrowableArray<int> Test"<<endl;
	GrowableArray <int> g(10);
	for (int i=0; i<g.length(); i++) g[i] = 2 * i + 3;
	cout << "g(10)"; g.print();
	g[13] = 13;
	cout << "g(26)"; g.print(); 
	cout<<"GrowableArray<double> Test"<<endl;
	GrowableArray<double> dg(10);
	int i;
	for(i = 0; i < dg.length(); i++) dg[i] = 2 * i + 3.14;
	cout<<"dg(10)"; dg.print();
	dg[13] = 13.31;
	cout<<"dg(26)"; dg.print();

	return 0;
}
