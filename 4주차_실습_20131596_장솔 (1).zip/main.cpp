#include <cstdio>
#include <cstring>
#include <iostream>

using namespace std;

// Node
template <typename T>
class Node{
	public:
		T data;
		Node *link;
		Node(T element){
			data = element;
			link = 0; 
		}
};

// LinkedList
template <typename T>
class LinkedList
{
	protected:
		Node<T> *first;
		int current_size;
	public:
		LinkedList(){
			first = 0;
			current_size = 0; 
		};
		int GetSize() { return current_size; }; // 노드 개수를 리턴
		void Insert(T element); // 맨 앞에 원소를 삽입
		virtual bool Delete(T &element); // 맨 뒤의 원소를 삭제
		void Print();	// 리스트를 출력
};
template <typename T>
void LinkedList<T>::Insert(T element) { // 새 노드를 맨 앞에 붙임
	Node<T> *newnode = new Node<T>(element);
	newnode->link = first;
	first = newnode;
	current_size++;
}
template <typename T>
bool LinkedList<T>::Delete(T &element){
	// 마지막 노드의 값을 리턴하면서, 메모리에서 할당 해제
	if(first == 0) return false;
	Node<T> *current = first, *previous = 0;
	while(1){    // 마지막 노드까지 찾아가는 반복문
		if(current->link == 0)    // find end node
		{
			if(previous) previous->link = current->link;
			else first = first->link;
			break;
		}
		previous = current;
		current = current->link;
	}
	element = current->data;
	delete current;
	current_size--;
	return true;
}
template <typename T>
void LinkedList<T>::Print() {
	Node<T> *nodePoint = first;
	int n = 1;
	if ( first == 0 );
	else {
		for ( ;; ) {
			if ( nodePoint->link == 0 ) {
				cout << "->"<< "[" << n << "|" << nodePoint->data << "]";
				break;
			}
			if ( n == 1 )cout << "[" << n << "|" << nodePoint->data << "]";
			else cout << "->"<< "[" << n << "|" << nodePoint->data << "]";
			n++;
			nodePoint = nodePoint->link;
		}
		cout << endl;
	}
}

// Stack
template <typename T>
class Stack:public LinkedList<T> {
	public:
		virtual bool Delete(T &element);
};
template <typename T>
bool Stack<T>::Delete(T &element) {
	if(this->first == 0) return false;
	Node<T> *current = this->first;
	this->first = this->first->link;
	delete current;
	this->current_size--;
	return true;
}
void prnMenu(){
	cout<<"*******************************************"<<endl;
	cout<<"* 1. 삽입    2. 삭제    3. 출력   4. 종료 *"<<endl;
	cout<<"*******************************************"<<endl;
	cout<<endl;
	cout<<"원하시는 메뉴를 골라주세요: ";
}

int main(void) 
{
	int mode, selectNumber, tmpItem;
	LinkedList<int> *p;
	bool flag = false;

	cout<<"자료구조 선택(1: Stack, Other: Linked List): ";
	cin>>mode;

	if(mode == 1)
		p = new Stack<int>();    
	else
		p = new LinkedList<int>();    
	do{
		prnMenu();
		cin>>selectNumber;
		switch(selectNumber){ 
			case 1:
				cout<<"원하시는 값을 입력해주세요: ";
				cin>>tmpItem;    p->Insert(tmpItem);
				cout<<tmpItem<<"가 삽입되었습니다."<<endl;
				break;
			case 2:
				if(p->Delete(tmpItem)==true)
					cout<<tmpItem<<"가 삭제되었습니다."<<endl;
				else cout<<"비어있습니다. 삭제 실패"<<endl;
				break;
			case 3:
				cout<<"크기: "<<p->GetSize()<<endl;
				p->Print();
				break;
			case 4:
				flag = true;     break;
			default:
				cout<<"잘못 입력하셨습니다."<<endl;
				break;
		}
		if(flag) break;
	} while(1);
	return 0;
}

